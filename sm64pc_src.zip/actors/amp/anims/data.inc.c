#include "anim_0800401C.inc.c"
