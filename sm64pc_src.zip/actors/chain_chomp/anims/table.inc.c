// 0x06025178
const struct Animation *const chain_chomp_seg6_anims_06025178[] = {
    &chain_chomp_seg6_anim_06025160,
    NULL,
};
