// 0x05005784
const struct Animation *const chair_seg5_anims_05005784[] = {
    &chair_seg5_anim_0500576C,
};
