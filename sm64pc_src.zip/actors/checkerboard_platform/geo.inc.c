// 0x0F0004E4
const GeoLayout checkerboard_platform_geo[] = {
   GEO_CULLING_RADIUS(400),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_OPAQUE, checkerboard_platform_seg8_dl_0800D680),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
