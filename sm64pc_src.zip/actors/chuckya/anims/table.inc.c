// 0x0800C070
const struct Animation *const chuckya_seg8_anims_0800C070[] = {
    &chuckya_seg8_anim_0800AF68,
    &chuckya_seg8_anim_0800B1A8,
    &chuckya_seg8_anim_0800B4A8,
    &chuckya_seg8_anim_0800B9F8,
    &chuckya_seg8_anim_0800BBEC,
    &chuckya_seg8_anim_0800C058,
};
