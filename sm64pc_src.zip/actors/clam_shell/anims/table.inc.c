// 0x05001744
const struct Animation *const clam_shell_seg5_anims_05001744[] = {
    &clam_shell_seg5_anim_05001654,
    &clam_shell_seg5_anim_0500172C,
    NULL,
};
