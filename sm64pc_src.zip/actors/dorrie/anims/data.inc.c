#include "anim_0600E18C.inc.c"
#include "anim_0600E9BC.inc.c"
#include "anim_0600F620.inc.c"
