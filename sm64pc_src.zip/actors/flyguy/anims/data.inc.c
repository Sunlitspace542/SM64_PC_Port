#include "anim_08011A4C.inc.c"
