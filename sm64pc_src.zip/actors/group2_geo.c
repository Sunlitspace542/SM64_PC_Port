#include <ultra64.h>
#include "sm64.h"
#include "geo_commands.h"

#include "make_const_nonconst.h"

#include "common1.h"
#include "group2.h"

#include "bully/geo.inc.c"
#include "blargg/geo.inc.c"
