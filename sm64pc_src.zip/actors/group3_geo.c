#include <ultra64.h>
#include "sm64.h"
#include "geo_commands.h"

#include "make_const_nonconst.h"

#include "common1.h"
#include "group3.h"

#include "king_bobomb/geo.inc.c"
#include "water_bubble/geo.inc.c"
