// 0x05005768
const struct Animation *const hoot_seg5_anims_05005768[] = {
    &hoot_seg5_anim_050053EC,
    &hoot_seg5_anim_05005750,
};
