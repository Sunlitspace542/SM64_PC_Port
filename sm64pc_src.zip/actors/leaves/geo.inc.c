// 0x16000C8C
const GeoLayout leaves_geo[] = {
   GEO_NODE_START(),
   GEO_OPEN_NODE(),
      GEO_DISPLAY_LIST(LAYER_ALPHA, leaves_seg3_dl_0301CDE0),
   GEO_CLOSE_NODE(),
   GEO_END(),
};
