#include "anim_05008CFC.inc.c"
